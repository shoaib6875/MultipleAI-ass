import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as Trash2, r as ExternalLink } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BkRtd2n9.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/**
* How the React page talks to FastAPI.
*
* The token from login is kept in localStorage. Every later call sends it as
* `Authorization: Bearer <token>`. The dev server forwards `/api` to FastAPI,
* so the browser only ever talks to one website.
*/
var TOKEN_KEY = "glimpse_token";
var SAMPLE_URL = "https://www.justdial.com/Hyderabad/Dr-Sarita-Rao-Tx-Hospitals-Near-Masjid-Uppal-Bus-Stand-Bharath-Nagar-Colony-Uppal/040PXX40-XX40-231215200040-Y2E1_BZDET";
function getToken() {
	if (typeof localStorage === "undefined") return null;
	return localStorage.getItem(TOKEN_KEY);
}
function setToken(token) {
	if (typeof localStorage === "undefined") return;
	if (token) localStorage.setItem(TOKEN_KEY, token);
	else localStorage.removeItem(TOKEN_KEY);
}
function errorMessage(body, fallback) {
	if (!body || typeof body !== "object") return fallback;
	const detail = body.detail;
	if (typeof detail === "string" && detail) return detail;
	return fallback;
}
async function request(path, options = {}) {
	const headers = new Headers(options.headers);
	if (options.body) headers.set("Content-Type", "application/json");
	const token = getToken();
	if (token) headers.set("Authorization", `Bearer ${token}`);
	let response;
	try {
		response = await fetch(path, {
			...options,
			headers
		});
	} catch {
		throw new Error("Can't reach the server. Is the API running?");
	}
	if (!response.ok) {
		let body = null;
		try {
			body = await response.json();
		} catch {
			body = null;
		}
		throw new Error(errorMessage(body, "Something went wrong. Try again."));
	}
	return await response.json();
}
async function signup(name, email, password) {
	const data = await request("/api/auth/signup", {
		method: "POST",
		body: JSON.stringify({
			name,
			email,
			password
		})
	});
	setToken(data.token);
	return data.user;
}
async function login(email, password) {
	const data = await request("/api/auth/login", {
		method: "POST",
		body: JSON.stringify({
			email,
			password
		})
	});
	setToken(data.token);
	return data.user;
}
async function currentUser() {
	if (!getToken()) return null;
	try {
		return (await request("/api/auth/me")).user;
	} catch {
		setToken(null);
		return null;
	}
}
function signOut() {
	setToken(null);
}
async function listSnapshots() {
	return (await request("/api/snapshots")).snapshots;
}
async function saveSnapshot(url) {
	return (await request("/api/snapshots", {
		method: "POST",
		body: JSON.stringify({ url })
	})).snapshot;
}
async function removeSnapshot(id) {
	await request(`/api/snapshots/${id}`, { method: "DELETE" });
}
async function loadPreview(id) {
	const token = getToken();
	if (!token) return null;
	const response = await fetch(`/api/snapshots/${id}/preview`, { headers: { Authorization: `Bearer ${token}` } });
	if (!response.ok) return null;
	const blob = await response.blob();
	return URL.createObjectURL(blob);
}
function Field({ label, type, value, autoComplete, onChange }) {
	const id = label.toLowerCase().replace(/\s+/g, "-");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block text-sm font-medium",
		htmlFor: id,
		children: [label, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			id,
			type,
			value,
			autoComplete,
			onChange: (event) => onChange(event.target.value),
			className: "mt-2 h-11 w-full rounded-control border border-line bg-bg px-3 text-base text-ink outline-none transition-[opacity,transform] duration-150 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ink"
		})]
	});
}
function AuthScreen({ onSignedIn }) {
	const [mode, setMode] = (0, import_react.useState)("signup");
	const [name, setName] = (0, import_react.useState)("");
	const [email, setEmail] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	async function onSubmit(event) {
		event.preventDefault();
		setError("");
		setBusy(true);
		try {
			onSignedIn(mode === "signup" ? await signup(name, email, password) : await login(email, password));
		} catch (err) {
			setError(err instanceof Error ? err.message : "Something went wrong");
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto flex min-h-dvh w-full max-w-5xl flex-col justify-center gap-10 px-5 py-10 md:flex-row md:items-center md:gap-16 md:px-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "md:flex-1",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium tracking-wide text-muted",
					children: "Glimpse"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-3 max-w-md font-display text-4xl font-medium leading-tight tracking-tight",
					children: "A shelf for web pages."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 max-w-md text-base text-muted",
					children: "Create an account, paste a link, and keep a picture of that page. Come back later and every snapshot is still here — only yours."
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "w-full rounded-sheet border border-line bg-surface p-6 shadow-panel md:max-w-md",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 gap-1 rounded-control bg-bg p-1",
				children: [["signup", "Create account"], ["login", "Sign in"]].map(([key, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => {
						setMode(key);
						setError("");
					},
					className: "h-10 rounded-sm text-sm font-medium transition-[opacity,transform] duration-150 " + (mode === key ? "bg-ink text-paper" : "text-muted"),
					children: label
				}, key))
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit,
				className: "mt-5 flex flex-col gap-4",
				children: [
					mode === "signup" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Name",
						type: "text",
						value: name,
						autoComplete: "name",
						onChange: setName
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Email",
						type: "email",
						value: email,
						autoComplete: "email",
						onChange: setEmail
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Password",
						type: "password",
						value: password,
						autoComplete: mode === "signup" ? "new-password" : "current-password",
						onChange: setPassword
					}),
					error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-danger",
						role: "alert",
						children: error
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: mode === "signup" ? "At least 8 characters." : "Use the email you signed up with."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "submit",
						disabled: busy,
						className: "h-11 rounded-control bg-ink text-sm font-medium text-paper transition-[opacity,transform] duration-150 hover:opacity-90 active:scale-[0.98] disabled:opacity-50",
						children: busy ? "Please wait…" : mode === "signup" ? "Create account" : "Sign in"
					})
				]
			})]
		})]
	});
}
function PreviewImage({ id, alt }) {
	const [src, setSrc] = (0, import_react.useState)(null);
	const [failed, setFailed] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		let cancelled = false;
		let objectUrl = null;
		loadPreview(id).then((url) => {
			if (cancelled) {
				if (url) URL.revokeObjectURL(url);
				return;
			}
			if (!url) {
				setFailed(true);
				return;
			}
			objectUrl = url;
			setSrc(url);
		}).catch(() => {
			if (!cancelled) setFailed(true);
		});
		return () => {
			cancelled = true;
			if (objectUrl) URL.revokeObjectURL(objectUrl);
		};
	}, [id]);
	if (failed || !src && failed) return null;
	if (!src) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "aspect-[16/10] w-full bg-bg motion-safe:animate-pulse" });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
		src,
		alt,
		className: "aspect-[16/10] w-full object-cover object-left-top"
	});
}
function formatWhen(iso) {
	const date = new Date(iso);
	if (Number.isNaN(date.getTime())) return "";
	return date.toLocaleString(void 0, {
		dateStyle: "medium",
		timeStyle: "short"
	});
}
function Shelf({ user }) {
	const [snapshots, setSnapshots] = (0, import_react.useState)([]);
	const [url, setUrl] = (0, import_react.useState)(SAMPLE_URL);
	const [error, setError] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [ready, setReady] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		let cancelled = false;
		listSnapshots().then((rows) => {
			if (!cancelled) setSnapshots(rows);
		}).catch((err) => {
			if (!cancelled) setError(err instanceof Error ? err.message : "Could not load saves");
		}).finally(() => {
			if (!cancelled) setReady(true);
		});
		return () => {
			cancelled = true;
		};
	}, []);
	async function onSubmit(event) {
		event.preventDefault();
		setError("");
		setBusy(true);
		try {
			const saved = await saveSnapshot(url);
			setSnapshots((current) => [saved, ...current]);
		} catch (err) {
			setError(err instanceof Error ? err.message : "Could not save that link");
		} finally {
			setBusy(false);
		}
	}
	async function onRemove(id) {
		setError("");
		try {
			await removeSnapshot(id);
			setSnapshots((current) => current.filter((item) => item.id !== id));
		} catch (err) {
			setError(err instanceof Error ? err.message : "Could not remove that page");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
			className: "border-b border-line",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex w-full max-w-5xl items-center justify-between gap-4 px-5 py-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-2xl font-medium tracking-tight",
					children: "Glimpse"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "hidden text-sm text-muted sm:block",
						children: user.email
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => {
							signOut();
							window.location.reload();
						},
						className: "h-11 rounded-control border border-line bg-surface px-4 text-sm font-medium transition-[opacity,transform] duration-150 hover:opacity-80",
						children: "Sign out"
					})]
				})]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
			className: "mx-auto w-full max-w-5xl px-5 py-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-3xl font-medium tracking-tight",
					children: "Save a page"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 max-w-xl text-muted",
					children: "Paste a link. We keep the address and a picture of the page, tied to your account."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit,
					className: "mt-6 rounded-panel border border-line bg-surface p-4 shadow-panel",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block text-sm font-medium",
							htmlFor: "page-url",
							children: ["Website URL", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								id: "page-url",
								type: "url",
								required: true,
								value: url,
								onChange: (event) => setUrl(event.target.value),
								placeholder: "https://",
								className: "mt-2 h-11 w-full rounded-control border border-line bg-bg px-3 text-base text-ink outline-none focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ink"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 flex flex-col gap-3 sm:flex-row sm:items-center",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "submit",
								disabled: busy,
								className: "h-11 rounded-control bg-ink px-5 text-sm font-medium text-paper transition-[opacity,transform] duration-150 hover:opacity-90 active:scale-[0.98] disabled:opacity-50",
								children: busy ? "Capturing preview…" : "Save preview"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setUrl(SAMPLE_URL),
								className: "h-11 rounded-control px-3 text-left text-sm font-medium text-muted",
								children: "Use the sample hospital page"
							})]
						}),
						busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-sm text-muted",
							children: "Opening the page and saving a picture. Sites that block bots can take about half a minute."
						}) : null,
						error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-sm text-danger",
							role: "alert",
							children: error
						}) : null
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "mt-10",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-sm font-medium tracking-wide text-muted",
							children: "Saved pages"
						}),
						!ready ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 text-muted",
							children: "Loading your shelf…"
						}) : null,
						ready && snapshots.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 max-w-md text-muted",
							children: "Nothing saved yet. The sample link is already in the box — press Save preview."
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-4 grid gap-6 sm:grid-cols-2",
							children: snapshots.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex min-w-0 flex-col overflow-hidden rounded-panel border border-line bg-surface shadow-panel",
								children: [item.has_preview ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewImage, {
									id: item.id,
									alt: `Preview of ${item.title}`
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex aspect-[16/10] items-end bg-bg p-4",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-display text-2xl font-medium tracking-tight",
										children: item.domain
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-1 flex-col gap-3 p-4",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "min-w-0",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
												className: "line-clamp-2 font-display text-xl font-medium leading-snug tracking-tight",
												children: item.title
											}), item.description ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "mt-1 line-clamp-2 text-sm text-muted",
												children: item.description
											}) : null]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "break-all text-sm text-muted",
											children: item.url
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "mt-auto flex items-center justify-between gap-3 pt-1",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-sm text-muted",
												children: formatWhen(item.created_at)
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-1",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
													href: item.url,
													target: "_blank",
													rel: "noreferrer",
													className: "inline-flex h-11 items-center gap-1 rounded-control px-3 text-sm font-medium",
													children: ["Open", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, {
														className: "size-4",
														"aria-hidden": "true"
													})]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
													type: "button",
													onClick: () => onRemove(item.id),
													className: "inline-flex h-11 items-center gap-1 rounded-control px-3 text-sm font-medium text-danger",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {
														className: "size-4",
														"aria-hidden": "true"
													}), "Remove"]
												})]
											})]
										})
									]
								})]
							}, item.id))
						})
					]
				})
			]
		})]
	});
}
function GlimpseApp() {
	const [user, setUser] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		let cancelled = false;
		currentUser().then((found) => {
			if (!cancelled && found) setUser(found);
		}).catch(() => {});
		return () => {
			cancelled = true;
		};
	}, []);
	if (!user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthScreen, { onSignedIn: (next) => {
		setUser(next);
	} });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shelf, { user });
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GlimpseApp, {});
}
//#endregion
export { Home as component };
