//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BN_LTotN.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-D7rOMpDJ.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-D7rOMpDJ.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-BH5P-p_Q.js"]
	}
} });
//#endregion
export { tsrStartManifest };
