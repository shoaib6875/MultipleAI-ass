"""Glimpse API — accounts, and a shelf of saved website previews.

Talk through this file top to bottom:

1. Passwords are hashed. We never store the original password.
2. Login returns a signed token (JWT). Later requests show that token.
3. A saved page is one database row plus an image file on disk.
4. Every query is filtered by the user id inside the token.
"""

from __future__ import annotations

import hashlib
import hmac
import os
import re
import socket
import sqlite3
import subprocess
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
from contextlib import asynccontextmanager, contextmanager
from datetime import datetime, timedelta, timezone
from html.parser import HTMLParser
from ipaddress import ip_address
from pathlib import Path

import jwt
from fastapi import Depends, FastAPI, Header, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from pydantic import BaseModel

BASE = Path(__file__).resolve().parent
REPO = BASE.parent
DATA = BASE / "data"
PREVIEWS = DATA / "previews"
DB_PATH = DATA / "glimpse.db"

SECRET = os.environ.get("GLIMPSE_JWT_SECRET", "glimpse-dev-secret-change-me-please-32b")
TOKEN_HOURS = 24 * 7
UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36 GlimpsePreview"
)

@asynccontextmanager
async def lifespan(_app: FastAPI):
    init_db()
    yield


app = FastAPI(title="Glimpse", version="1.0.0", lifespan=lifespan)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


# --- tiny database -------------------------------------------------------

def connect() -> sqlite3.Connection:
    DATA.mkdir(parents=True, exist_ok=True)
    PREVIEWS.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


@contextmanager
def database():
    conn = connect()
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def init_db() -> None:
    with database() as conn:
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS users (
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              name TEXT NOT NULL,
              email TEXT NOT NULL UNIQUE,
              password_hash TEXT NOT NULL,
              created_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS snapshots (
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              user_id INTEGER NOT NULL REFERENCES users(id),
              url TEXT NOT NULL,
              title TEXT NOT NULL,
              description TEXT NOT NULL,
              domain TEXT NOT NULL,
              preview_file TEXT,
              preview_mime TEXT,
              preview_source TEXT NOT NULL DEFAULT '',
              created_at TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_snapshots_user
              ON snapshots(user_id, id DESC);
            """
        )


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


# --- passwords and tokens ------------------------------------------------

def hash_password(password: str) -> str:
    salt = os.urandom(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, 200_000)
    return f"{salt.hex()}:{digest.hex()}"


def verify_password(password: str, stored: str) -> bool:
    try:
        salt_hex, digest_hex = stored.split(":", 1)
        digest = hashlib.pbkdf2_hmac(
            "sha256", password.encode(), bytes.fromhex(salt_hex), 200_000
        )
    except (ValueError, TypeError):
        return False
    return hmac.compare_digest(digest.hex(), digest_hex)


def make_token(user_id: int) -> str:
    payload = {
        "sub": str(user_id),
        "exp": datetime.now(timezone.utc) + timedelta(hours=TOKEN_HOURS),
    }
    return jwt.encode(payload, SECRET, algorithm="HS256")


def user_from_token(token: str) -> sqlite3.Row:
    try:
        payload = jwt.decode(token, SECRET, algorithms=["HS256"])
        user_id = int(payload["sub"])
    except (jwt.PyJWTError, KeyError, ValueError):
        raise HTTPException(status_code=401, detail="Please sign in again")
    with database() as conn:
        row = conn.execute("SELECT id, name, email FROM users WHERE id = ?", (user_id,)).fetchone()
    if row is None:
        raise HTTPException(status_code=401, detail="Please sign in again")
    return row


def current_user(authorization: str | None = Header(default=None)) -> sqlite3.Row:
    if not authorization or not authorization.lower().startswith("bearer "):
        raise HTTPException(status_code=401, detail="Please sign in again")
    return user_from_token(authorization.split(" ", 1)[1].strip())


def public_user(row: sqlite3.Row) -> dict:
    return {"id": row["id"], "name": row["name"], "email": row["email"]}


# --- accounts ------------------------------------------------------------

class SignupIn(BaseModel):
    name: str
    email: str
    password: str


class LoginIn(BaseModel):
    email: str
    password: str


def clean_email(value: str) -> str:
    email = value.strip().lower()
    if not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", email):
        raise HTTPException(status_code=422, detail="Enter a valid email address")
    return email


@app.post("/api/auth/signup")
def signup(body: SignupIn) -> dict:
    name = body.name.strip()
    if not name or len(name) > 80:
        raise HTTPException(status_code=422, detail="Name should be 1–80 characters")
    email = clean_email(body.email)
    if len(body.password) < 8 or len(body.password) > 72:
        raise HTTPException(status_code=422, detail="Password should be 8–72 characters")
    try:
        with database() as conn:
            cur = conn.execute(
                "INSERT INTO users (name, email, password_hash, created_at) VALUES (?, ?, ?, ?)",
                (name, email, hash_password(body.password), now_iso()),
            )
            user_id = int(cur.lastrowid)
    except sqlite3.IntegrityError:
        raise HTTPException(status_code=409, detail="An account with that email already exists")
    return {"token": make_token(user_id), "user": {"id": user_id, "name": name, "email": email}}


@app.post("/api/auth/login")
def login(body: LoginIn) -> dict:
    email = clean_email(body.email)
    with database() as conn:
        row = conn.execute(
            "SELECT id, name, email, password_hash FROM users WHERE email = ?",
            (email,),
        ).fetchone()
    if row is None or not verify_password(body.password, row["password_hash"]):
        raise HTTPException(status_code=401, detail="Email or password is incorrect")
    return {"token": make_token(int(row["id"])), "user": public_user(row)}


@app.get("/api/auth/me")
def me(user: sqlite3.Row = Depends(current_user)) -> dict:
    return {"user": public_user(user)}


@app.get("/api/health")
def health() -> dict:
    return {"ok": True}


# --- links ---------------------------------------------------------------

class SnapshotIn(BaseModel):
    url: str


def assert_public_host(host: str) -> None:
    lowered = host.lower().strip(".")
    if lowered in {"localhost", "localhost.localdomain"} or lowered.endswith(".local"):
        raise HTTPException(status_code=422, detail="That address is not allowed")
    try:
        infos = socket.getaddrinfo(lowered, None)
    except socket.gaierror:
        raise HTTPException(status_code=422, detail="Could not find that website")
    seen = False
    for info in infos:
        seen = True
        ip = ip_address(info[4][0])
        if (
            ip.is_private
            or ip.is_loopback
            or ip.is_link_local
            or ip.is_reserved
            or ip.is_multicast
            or ip.is_unspecified
        ):
            raise HTTPException(status_code=422, detail="That address is not allowed")
    if not seen:
        raise HTTPException(status_code=422, detail="Could not find that website")


def normalize_url(raw: str) -> str:
    text = raw.strip()
    if not text or len(text) > 2000:
        raise HTTPException(status_code=422, detail="Paste a website link first")
    if not re.match(r"^https?://", text, flags=re.I):
        text = "https://" + text
    parsed = urllib.parse.urlparse(text)
    if parsed.scheme.lower() not in {"http", "https"} or not parsed.hostname:
        raise HTTPException(status_code=422, detail="Use a full http or https link")
    if parsed.username or parsed.password:
        raise HTTPException(status_code=422, detail="That link is not allowed")
    assert_public_host(parsed.hostname)
    return text


def fallback_copy(url: str) -> tuple[str, str, str]:
    """When the site won't give us a title, read one from the link itself."""
    parsed = urllib.parse.urlparse(url)
    host = (parsed.hostname or "").removeprefix("www.")
    segments = [urllib.parse.unquote(part) for part in parsed.path.split("/") if part]
    place = ""
    labels: list[str] = []
    for index, segment in enumerate(segments):
        if re.search(r"\d", segment) and len(segment) > 16:
            continue
        label = segment.replace("-", " ").replace("_", " ").strip()
        if not label:
            continue
        if index == 0 and "-" not in segment and len(segment) < 28:
            place = label
            continue
        labels.append(label)
    title = " ".join(labels)[:160] or host or url
    description = " · ".join(bit for bit in (place, host) if bit)
    return title, description, host


class MetaParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self._in_title = False
        self.title_parts: list[str] = []
        self.metas: list[dict[str, str]] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        attr = {key.lower(): (value or "") for key, value in attrs}
        if tag == "title":
            self._in_title = True
        elif tag == "meta":
            self.metas.append(attr)

    def handle_endtag(self, tag: str) -> None:
        if tag == "title":
            self._in_title = False

    def handle_data(self, data: str) -> None:
        if self._in_title:
            self.title_parts.append(data)


def _meta(metas: list[dict[str, str]], *keys: str) -> str:
    wanted = {key.lower() for key in keys}
    for item in metas:
        name = (item.get("property") or item.get("name") or "").lower()
        if name in wanted and item.get("content"):
            return " ".join(item["content"].split())
    return ""


def fetch_html_meta(url: str) -> dict[str, str]:
    """Best-effort title and description. Failure just means we use the link text."""
    try:
        request = urllib.request.Request(url, headers={"User-Agent": UA, "Accept": "text/html"})
        with urllib.request.urlopen(request, timeout=8) as response:
            content_type = (response.headers.get("content-type") or "").lower()
            if "html" not in content_type:
                return {}
            raw = response.read(350_000)
            final_url = response.geturl()
    except (urllib.error.URLError, TimeoutError, ValueError):
        return {}
    parser = MetaParser()
    try:
        parser.feed(raw.decode("utf-8", errors="replace"))
    except Exception:
        return {}
    title = _meta(parser.metas, "og:title", "twitter:title") or " ".join(
        "".join(parser.title_parts).split()
    )
    description = _meta(
        parser.metas, "og:description", "twitter:description", "description"
    )
    image = _meta(parser.metas, "og:image", "twitter:image")
    if image:
        image = urllib.parse.urljoin(final_url, image)
    blocked = re.search(
        r"access denied|pardon our interruption|just a moment|attention required",
        title,
        flags=re.I,
    )
    if blocked:
        return {}
    return {
        "title": title[:160],
        "description": description[:280],
        "image": image,
    }


def capture_with_browser(url: str, dest: Path) -> bool:
    """Our own headless Chrome. Works for ordinary sites. Some sites block it."""
    try:
        completed = subprocess.run(
            ["node", str(BASE / "capture.mjs"), url, str(dest)],
            cwd=str(REPO),
            capture_output=True,
            text=True,
            timeout=28,
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        print(f"[glimpse] browser capture failed: {exc}")
        dest.unlink(missing_ok=True)
        return False
    if completed.returncode == 0 and dest.exists() and dest.stat().st_size > 2000:
        return True
    if completed.stderr:
        print(f"[glimpse] browser capture: {completed.stderr.strip()[:300]}")
    dest.unlink(missing_ok=True)
    return False


def download_snapshot_service(url: str, dest: Path) -> bool:
    """Fallback used when a site (like Justdial) refuses our server's browser."""
    shot = "https://image.thum.io/get/width/1200/crop/780/noanimate/" + url
    for attempt in (1, 2):
        try:
            request = urllib.request.Request(shot, headers={"User-Agent": UA})
            with urllib.request.urlopen(request, timeout=45) as response:
                content_type = (response.headers.get("content-type") or "").split(";")[0].lower()
                data = response.read(5_000_000)
        except (urllib.error.URLError, TimeoutError, ValueError) as exc:
            print(f"[glimpse] snapshot service failed: {exc}")
            data = b""
            content_type = ""
        if content_type.startswith("image/") and len(data) >= 8000:
            dest.write_bytes(data)
            return True
        if attempt == 1:
            time.sleep(2)
    dest.unlink(missing_ok=True)
    return False


def download_remote_image(image_url: str, dest: Path) -> bool:
    parsed = urllib.parse.urlparse(image_url)
    if parsed.scheme not in {"http", "https"} or not parsed.hostname:
        return False
    try:
        assert_public_host(parsed.hostname)
        request = urllib.request.Request(image_url, headers={"User-Agent": UA})
        with urllib.request.urlopen(request, timeout=12) as response:
            content_type = (response.headers.get("content-type") or "").split(";")[0].lower()
            data = response.read(5_000_000)
    except (urllib.error.URLError, TimeoutError, HTTPException, ValueError):
        return False
    if not content_type.startswith("image/") or len(data) < 1000:
        return False
    dest.write_bytes(data)
    return True


def build_preview(url: str) -> dict[str, str]:
    meta = fetch_html_meta(url)
    title_fb, description_fb, domain = fallback_copy(url)
    stem = PREVIEWS / uuid.uuid4().hex
    preview_file = ""
    preview_mime = ""
    preview_source = ""

    jpg = stem.with_suffix(".jpg")
    png = stem.with_suffix(".png")
    if capture_with_browser(url, jpg):
        preview_file, preview_mime, preview_source = jpg.name, "image/jpeg", "browser"
    elif download_snapshot_service(url, png):
        preview_file, preview_mime, preview_source = png.name, "image/png", "snapshot"
    elif meta.get("image") and download_remote_image(meta["image"], jpg):
        preview_file, preview_mime, preview_source = jpg.name, "image/jpeg", "opengraph"

    return {
        "title": (meta.get("title") or title_fb)[:160],
        "description": (meta.get("description") or description_fb)[:280],
        "domain": domain,
        "preview_file": preview_file,
        "preview_mime": preview_mime,
        "preview_source": preview_source,
    }


def snapshot_out(row: sqlite3.Row) -> dict:
    return {
        "id": row["id"],
        "url": row["url"],
        "title": row["title"],
        "description": row["description"],
        "domain": row["domain"],
        "has_preview": bool(row["preview_file"]),
        "preview_source": row["preview_source"] or "",
        "created_at": row["created_at"],
    }


@app.get("/api/snapshots")
def list_snapshots(user: sqlite3.Row = Depends(current_user)) -> dict:
    with database() as conn:
        rows = conn.execute(
            "SELECT * FROM snapshots WHERE user_id = ? ORDER BY id DESC",
            (user["id"],),
        ).fetchall()
    return {"snapshots": [snapshot_out(row) for row in rows]}


@app.post("/api/snapshots")
def create_snapshot(body: SnapshotIn, user: sqlite3.Row = Depends(current_user)) -> dict:
    url = normalize_url(body.url)
    preview = build_preview(url)
    with database() as conn:
        cur = conn.execute(
            """
            INSERT INTO snapshots (
              user_id, url, title, description, domain,
              preview_file, preview_mime, preview_source, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                user["id"],
                url,
                preview["title"],
                preview["description"],
                preview["domain"],
                preview["preview_file"] or None,
                preview["preview_mime"] or None,
                preview["preview_source"],
                now_iso(),
            ),
        )
        new_id = int(cur.lastrowid)
        row = conn.execute("SELECT * FROM snapshots WHERE id = ?", (new_id,)).fetchone()
    print(f"[glimpse] saved {url} via {preview['preview_source'] or 'none'}")
    return {"snapshot": snapshot_out(row)}


@app.get("/api/snapshots/{snapshot_id}/preview")
def snapshot_preview(snapshot_id: int, user: sqlite3.Row = Depends(current_user)) -> FileResponse:
    with database() as conn:
        row = conn.execute(
            "SELECT preview_file, preview_mime FROM snapshots WHERE id = ? AND user_id = ?",
            (snapshot_id, user["id"]),
        ).fetchone()
    if row is None or not row["preview_file"]:
        raise HTTPException(status_code=404, detail="No preview saved for that page")
    filename = Path(row["preview_file"]).name
    path = PREVIEWS / filename
    if not path.is_file():
        raise HTTPException(status_code=404, detail="No preview saved for that page")
    return FileResponse(path, media_type=row["preview_mime"] or "image/jpeg")


@app.delete("/api/snapshots/{snapshot_id}")
def delete_snapshot(snapshot_id: int, user: sqlite3.Row = Depends(current_user)) -> dict:
    with database() as conn:
        row = conn.execute(
            "SELECT preview_file FROM snapshots WHERE id = ? AND user_id = ?",
            (snapshot_id, user["id"]),
        ).fetchone()
        if row is None:
            raise HTTPException(status_code=404, detail="That saved page was not found")
        conn.execute(
            "DELETE FROM snapshots WHERE id = ? AND user_id = ?",
            (snapshot_id, user["id"]),
        )
    if row["preview_file"]:
        (PREVIEWS / Path(row["preview_file"]).name).unlink(missing_ok=True)
    return {"ok": True}
