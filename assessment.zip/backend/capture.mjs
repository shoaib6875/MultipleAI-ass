/**
 * Opens a public URL in headless Chromium and writes a JPEG preview.
 *
 * Usage: node backend/capture.mjs <url> <output.jpg>
 * Exit 0: picture saved.
 * Exit 3: the site showed a bot wall (Access Denied, captcha, etc.).
 * Exit 1: anything else failed.
 */
import { chromium } from "playwright";
import { mkdirSync } from "node:fs";
import { dirname } from "node:path";

const url = process.argv[2];
const out = process.argv[3];

if (!url || !out) {
  console.error("Usage: node backend/capture.mjs <url> <output.jpg>");
  process.exit(2);
}

const BLOCKED =
  /access denied|pardon our interruption|just a moment|attention required|forbidden|captcha|are you a human/i;

const browser = await chromium.launch({
  headless: true,
  args: ["--no-sandbox", "--disable-dev-shm-usage", "--disable-gpu"],
});

try {
  const page = await browser.newPage({
    viewport: { width: 1280, height: 800 },
    userAgent:
      "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
  });
  await page.goto(url, { waitUntil: "domcontentloaded", timeout: 18000 });
  await page.waitForTimeout(800);
  const title = await page.title();
  if (BLOCKED.test(title)) {
    console.error(`blocked:${title}`);
    process.exit(3);
  }
  mkdirSync(dirname(out), { recursive: true });
  await page.screenshot({ path: out, type: "jpeg", quality: 72 });
} finally {
  await browser.close();
}
