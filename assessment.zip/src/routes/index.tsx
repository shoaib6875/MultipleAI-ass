import { createFileRoute } from "@tanstack/react-router";
import { GlimpseApp } from "@/components/glimpse-app";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <GlimpseApp />;
}
