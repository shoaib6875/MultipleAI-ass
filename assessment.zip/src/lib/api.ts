/**
 * How the React page talks to FastAPI.
 *
 * The token from login is kept in localStorage. Every later call sends it as
 * `Authorization: Bearer <token>`. The dev server forwards `/api` to FastAPI,
 * so the browser only ever talks to one website.
 */

const TOKEN_KEY = "glimpse_token";

export const SAMPLE_URL =
  "https://www.justdial.com/Hyderabad/Dr-Sarita-Rao-Tx-Hospitals-Near-Masjid-Uppal-Bus-Stand-Bharath-Nagar-Colony-Uppal/040PXX40-XX40-231215200040-Y2E1_BZDET";

export type User = {
  id: number;
  name: string;
  email: string;
};

export type Snapshot = {
  id: number;
  url: string;
  title: string;
  description: string;
  domain: string;
  has_preview: boolean;
  preview_source: string;
  created_at: string;
};

export function getToken(): string | null {
  if (typeof localStorage === "undefined") return null;
  return localStorage.getItem(TOKEN_KEY);
}

export function setToken(token: string | null): void {
  if (typeof localStorage === "undefined") return;
  if (token) localStorage.setItem(TOKEN_KEY, token);
  else localStorage.removeItem(TOKEN_KEY);
}

function errorMessage(body: unknown, fallback: string): string {
  if (!body || typeof body !== "object") return fallback;
  const detail = (body as { detail?: unknown }).detail;
  if (typeof detail === "string" && detail) return detail;
  return fallback;
}

async function request<T>(path: string, options: RequestInit = {}): Promise<T> {
  const headers = new Headers(options.headers);
  if (options.body) headers.set("Content-Type", "application/json");
  const token = getToken();
  if (token) headers.set("Authorization", `Bearer ${token}`);

  let response: Response;
  try {
    response = await fetch(path, { ...options, headers });
  } catch {
    throw new Error("Can't reach the server. Is the API running?");
  }

  if (!response.ok) {
    let body: unknown = null;
    try {
      body = await response.json();
    } catch {
      body = null;
    }
    throw new Error(errorMessage(body, "Something went wrong. Try again."));
  }

  return (await response.json()) as T;
}

export async function signup(name: string, email: string, password: string): Promise<User> {
  const data = await request<{ token: string; user: User }>("/api/auth/signup", {
    method: "POST",
    body: JSON.stringify({ name, email, password }),
  });
  setToken(data.token);
  return data.user;
}

export async function login(email: string, password: string): Promise<User> {
  const data = await request<{ token: string; user: User }>("/api/auth/login", {
    method: "POST",
    body: JSON.stringify({ email, password }),
  });
  setToken(data.token);
  return data.user;
}

export async function currentUser(): Promise<User | null> {
  if (!getToken()) return null;
  try {
    const data = await request<{ user: User }>("/api/auth/me");
    return data.user;
  } catch {
    setToken(null);
    return null;
  }
}

export function signOut(): void {
  setToken(null);
}

export async function listSnapshots(): Promise<Snapshot[]> {
  const data = await request<{ snapshots: Snapshot[] }>("/api/snapshots");
  return data.snapshots;
}

export async function saveSnapshot(url: string): Promise<Snapshot> {
  const data = await request<{ snapshot: Snapshot }>("/api/snapshots", {
    method: "POST",
    body: JSON.stringify({ url }),
  });
  return data.snapshot;
}

export async function removeSnapshot(id: number): Promise<void> {
  await request<{ ok: boolean }>(`/api/snapshots/${id}`, { method: "DELETE" });
}

export async function loadPreview(id: number): Promise<string | null> {
  const token = getToken();
  if (!token) return null;
  const response = await fetch(`/api/snapshots/${id}/preview`, {
    headers: { Authorization: `Bearer ${token}` },
  });
  if (!response.ok) return null;
  const blob = await response.blob();
  return URL.createObjectURL(blob);
}
