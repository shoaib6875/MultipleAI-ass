import { useEffect, useState, type FormEvent } from "react";
import { ExternalLink, Trash2 } from "lucide-react";
import {
  SAMPLE_URL,
  currentUser,
  listSnapshots,
  loadPreview,
  login,
  removeSnapshot,
  saveSnapshot,
  signOut,
  signup,
  type Snapshot,
  type User,
} from "@/lib/api";

type Mode = "login" | "signup";

function Field({
  label,
  type,
  value,
  autoComplete,
  onChange,
}: {
  label: string;
  type: string;
  value: string;
  autoComplete: string;
  onChange: (value: string) => void;
}) {
  const id = label.toLowerCase().replace(/\s+/g, "-");
  return (
    <label className="block text-sm font-medium" htmlFor={id}>
      {label}
      <input
        id={id}
        type={type}
        value={value}
        autoComplete={autoComplete}
        onChange={(event) => onChange(event.target.value)}
        className="mt-2 h-11 w-full rounded-control border border-line bg-bg px-3 text-base text-ink outline-none transition-[opacity,transform] duration-150 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ink"
      />
    </label>
  );
}

function AuthScreen({ onSignedIn }: { onSignedIn: (user: User) => void }) {
  const [mode, setMode] = useState<Mode>("signup");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function onSubmit(event: FormEvent) {
    event.preventDefault();
    setError("");
    setBusy(true);
    try {
      const user =
        mode === "signup"
          ? await signup(name, email, password)
          : await login(email, password);
      onSignedIn(user);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong");
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="mx-auto flex min-h-dvh w-full max-w-5xl flex-col justify-center gap-10 px-5 py-10 md:flex-row md:items-center md:gap-16 md:px-8">
      <section className="md:flex-1">
        <p className="text-sm font-medium tracking-wide text-muted">Glimpse</p>
        <h1 className="mt-3 max-w-md font-display text-4xl font-medium leading-tight tracking-tight">
          A shelf for web pages.
        </h1>
        <p className="mt-4 max-w-md text-base text-muted">
          Create an account, paste a link, and keep a picture of that page. Come back later
          and every snapshot is still here — only yours.
        </p>
      </section>

      <section className="w-full rounded-sheet border border-line bg-surface p-6 shadow-panel md:max-w-md">
        <div className="grid grid-cols-2 gap-1 rounded-control bg-bg p-1">
          {(
            [
              ["signup", "Create account"],
              ["login", "Sign in"],
            ] as const
          ).map(([key, label]) => (
            <button
              key={key}
              type="button"
              onClick={() => {
                setMode(key);
                setError("");
              }}
              className={
                "h-10 rounded-sm text-sm font-medium transition-[opacity,transform] duration-150 " +
                (mode === key ? "bg-ink text-paper" : "text-muted")
              }
            >
              {label}
            </button>
          ))}
        </div>

        <form onSubmit={onSubmit} className="mt-5 flex flex-col gap-4">
          {mode === "signup" ? (
            <Field label="Name" type="text" value={name} autoComplete="name" onChange={setName} />
          ) : null}
          <Field
            label="Email"
            type="email"
            value={email}
            autoComplete="email"
            onChange={setEmail}
          />
          <Field
            label="Password"
            type="password"
            value={password}
            autoComplete={mode === "signup" ? "new-password" : "current-password"}
            onChange={setPassword}
          />
          {error ? (
            <p className="text-sm text-danger" role="alert">
              {error}
            </p>
          ) : (
            <p className="text-sm text-muted">
              {mode === "signup" ? "At least 8 characters." : "Use the email you signed up with."}
            </p>
          )}
          <button
            type="submit"
            disabled={busy}
            className="h-11 rounded-control bg-ink text-sm font-medium text-paper transition-[opacity,transform] duration-150 hover:opacity-90 active:scale-[0.98] disabled:opacity-50"
          >
            {busy ? "Please wait…" : mode === "signup" ? "Create account" : "Sign in"}
          </button>
        </form>
      </section>
    </main>
  );
}

function PreviewImage({ id, alt }: { id: number; alt: string }) {
  const [src, setSrc] = useState<string | null>(null);
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    let cancelled = false;
    let objectUrl: string | null = null;
    loadPreview(id)
      .then((url) => {
        if (cancelled) {
          if (url) URL.revokeObjectURL(url);
          return;
        }
        if (!url) {
          setFailed(true);
          return;
        }
        objectUrl = url;
        setSrc(url);
      })
      .catch(() => {
        if (!cancelled) setFailed(true);
      });
    return () => {
      cancelled = true;
      if (objectUrl) URL.revokeObjectURL(objectUrl);
    };
  }, [id]);

  if (failed || (!src && failed)) {
    return null;
  }

  if (!src) {
    return <div className="aspect-[16/10] w-full bg-bg motion-safe:animate-pulse" />;
  }

  return (
    <img
      src={src}
      alt={alt}
      className="aspect-[16/10] w-full object-cover object-left-top"
    />
  );
}

function formatWhen(iso: string): string {
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return "";
  return date.toLocaleString(undefined, { dateStyle: "medium", timeStyle: "short" });
}

function Shelf({ user }: { user: User }) {
  const [snapshots, setSnapshots] = useState<Snapshot[]>([]);
  const [url, setUrl] = useState(SAMPLE_URL);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    let cancelled = false;
    listSnapshots()
      .then((rows) => {
        if (!cancelled) setSnapshots(rows);
      })
      .catch((err: unknown) => {
        if (!cancelled) setError(err instanceof Error ? err.message : "Could not load saves");
      })
      .finally(() => {
        if (!cancelled) setReady(true);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  async function onSubmit(event: FormEvent) {
    event.preventDefault();
    setError("");
    setBusy(true);
    try {
      const saved = await saveSnapshot(url);
      setSnapshots((current) => [saved, ...current]);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not save that link");
    } finally {
      setBusy(false);
    }
  }

  async function onRemove(id: number) {
    setError("");
    try {
      await removeSnapshot(id);
      setSnapshots((current) => current.filter((item) => item.id !== id));
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not remove that page");
    }
  }

  return (
    <div className="min-h-dvh">
      <header className="border-b border-line">
        <div className="mx-auto flex w-full max-w-5xl items-center justify-between gap-4 px-5 py-4">
          <p className="font-display text-2xl font-medium tracking-tight">Glimpse</p>
          <div className="flex items-center gap-3">
            <p className="hidden text-sm text-muted sm:block">{user.email}</p>
            <button
              type="button"
              onClick={() => {
                signOut();
                window.location.reload();
              }}
              className="h-11 rounded-control border border-line bg-surface px-4 text-sm font-medium transition-[opacity,transform] duration-150 hover:opacity-80"
            >
              Sign out
            </button>
          </div>
        </div>
      </header>

      <main className="mx-auto w-full max-w-5xl px-5 py-8">
        <h1 className="font-display text-3xl font-medium tracking-tight">Save a page</h1>
        <p className="mt-2 max-w-xl text-muted">
          Paste a link. We keep the address and a picture of the page, tied to your account.
        </p>

        <form onSubmit={onSubmit} className="mt-6 rounded-panel border border-line bg-surface p-4 shadow-panel">
          <label className="block text-sm font-medium" htmlFor="page-url">
            Website URL
            <input
              id="page-url"
              type="url"
              required
              value={url}
              onChange={(event) => setUrl(event.target.value)}
              placeholder="https://"
              className="mt-2 h-11 w-full rounded-control border border-line bg-bg px-3 text-base text-ink outline-none focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ink"
            />
          </label>
          <div className="mt-3 flex flex-col gap-3 sm:flex-row sm:items-center">
            <button
              type="submit"
              disabled={busy}
              className="h-11 rounded-control bg-ink px-5 text-sm font-medium text-paper transition-[opacity,transform] duration-150 hover:opacity-90 active:scale-[0.98] disabled:opacity-50"
            >
              {busy ? "Capturing preview…" : "Save preview"}
            </button>
            <button
              type="button"
              onClick={() => setUrl(SAMPLE_URL)}
              className="h-11 rounded-control px-3 text-left text-sm font-medium text-muted"
            >
              Use the sample hospital page
            </button>
          </div>
          {busy ? (
            <p className="mt-3 text-sm text-muted">
              Opening the page and saving a picture. Sites that block bots can take about half a minute.
            </p>
          ) : null}
          {error ? (
            <p className="mt-3 text-sm text-danger" role="alert">
              {error}
            </p>
          ) : null}
        </form>

        <section className="mt-10">
          <h2 className="text-sm font-medium tracking-wide text-muted">Saved pages</h2>
          {!ready ? <p className="mt-4 text-muted">Loading your shelf…</p> : null}
          {ready && snapshots.length === 0 ? (
            <p className="mt-4 max-w-md text-muted">
              Nothing saved yet. The sample link is already in the box — press Save preview.
            </p>
          ) : null}
          <ul className="mt-4 grid gap-6 sm:grid-cols-2">
            {snapshots.map((item) => (
              <li
                key={item.id}
                className="flex min-w-0 flex-col overflow-hidden rounded-panel border border-line bg-surface shadow-panel"
              >
                {item.has_preview ? (
                  <PreviewImage id={item.id} alt={`Preview of ${item.title}`} />
                ) : (
                  <div className="flex aspect-[16/10] items-end bg-bg p-4">
                    <p className="font-display text-2xl font-medium tracking-tight">{item.domain}</p>
                  </div>
                )}
                <div className="flex flex-1 flex-col gap-3 p-4">
                  <div className="min-w-0">
                    <h3 className="line-clamp-2 font-display text-xl font-medium leading-snug tracking-tight">
                      {item.title}
                    </h3>
                    {item.description ? (
                      <p className="mt-1 line-clamp-2 text-sm text-muted">{item.description}</p>
                    ) : null}
                  </div>
                  <p className="break-all text-sm text-muted">{item.url}</p>
                  <div className="mt-auto flex items-center justify-between gap-3 pt-1">
                    <p className="text-sm text-muted">{formatWhen(item.created_at)}</p>
                    <div className="flex items-center gap-1">
                      <a
                        href={item.url}
                        target="_blank"
                        rel="noreferrer"
                        className="inline-flex h-11 items-center gap-1 rounded-control px-3 text-sm font-medium"
                      >
                        Open
                        <ExternalLink className="size-4" aria-hidden="true" />
                      </a>
                      <button
                        type="button"
                        onClick={() => onRemove(item.id)}
                        className="inline-flex h-11 items-center gap-1 rounded-control px-3 text-sm font-medium text-danger"
                      >
                        <Trash2 className="size-4" aria-hidden="true" />
                        Remove
                      </button>
                    </div>
                  </div>
                </div>
              </li>
            ))}
          </ul>
        </section>
      </main>
    </div>
  );
}

export function GlimpseApp() {
  const [user, setUser] = useState<User | null>(null);

  useEffect(() => {
    let cancelled = false;
    currentUser()
      .then((found) => {
        if (!cancelled && found) setUser(found);
      })
      .catch(() => {
        // Stay on the account form. A bad token is already cleared in currentUser.
      });
    return () => {
      cancelled = true;
    };
  }, []);

  if (!user) {
    return (
      <AuthScreen
        onSignedIn={(next) => {
          setUser(next);
        }}
      />
    );
  }

  return <Shelf user={user} />;
}
